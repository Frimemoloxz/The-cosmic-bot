let handler = async (m, { conn }) => {
  // Define la cantidad de XP a otorgar
  let amount = 25000000;
  
  // Accede a los datos del usuario
  let user = global.db.data.users[m.sender];

  // Asegúrate de que el usuario exista en la base de datos
  if (!user) {
    user = global.db.data.users[m.sender] = { xp: 0 };
  }

  // Añade la cantidad de XP al usuario
  user.exp = (user.exp 