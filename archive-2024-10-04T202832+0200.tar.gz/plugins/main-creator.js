let handler = async (m, { conn, usedPrefix, isOwner }) => {
let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:;FRI MEMO;;\n:FRI MEMO\nORG:FRI MEMO\nTITLE:\nitem1.TEL;waid=5493804166508:5493804166508\nitem1.X-ABLabel:FRI MEMO\nX-WA-BIZ-DESCRIPTION:\nX-WA-BIZ-NAME:FRI MEMO\nEND:VCARD`
await conn.sendMessage(m.chat, { contacts: { displayName: 'Fri memo', contacts: [{ vcard }] }}, {quoted: m})
}
handler.help = ['owner']
handler.tags = ['main']
handler.command = ['owner', 'creator', 'creador', 'dueño', 'memo', 'fri memo'] 

export default handler