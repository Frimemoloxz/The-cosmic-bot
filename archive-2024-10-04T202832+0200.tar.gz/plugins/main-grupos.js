import fetch from 'node-fetch'

let handler  = async (m, { conn, usedPrefix, command }) => {
let img = await (await fetch(`https://tinyurl.com/2776kmrb`)).buffer()
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
let txt = `*-Grupos oficiales del bot-*

*grupo 1:* 
[https://chat.whatsapp.com/G1pE7LsYd1sLivbYhLuoIJ]

*grupo 2:*
[https://chat.whatsapp.com/JSBMtb65g9tHg8NNAKLVmY]

*grupo 3:*
[https://chat.whatsapp.com/Lirdno8uFweEJbXAotIZVn]

nuestro canal oficial...
[https://whatsapp.com/channel/0029VadwYAfBvvsbqX5VVt3m]

> unete plis`
await conn.sendFile(m.chat, img, "Thumbnail.jpg", txt, m, null, rcanal)
}
handler.help = ['grupos']
handler.tags = ['main']
handler.command = /^(grupos)$/i
export default handler