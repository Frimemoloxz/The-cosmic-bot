const free = 200000
const prem = 400000
const cooldowns = {}

let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender]
  const tiempoEspera = 7 * 24 * 60 * 60 // 7 días en segundos
  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    const tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000))
    conn.reply(m.chat, `Ya has realizado tu pedido semanal.\nRecuerda que solo puedes realizarlo 1 vez cada 7 días.\n\n*Próximo Monto* : +${isPrems ? prem : free} 💫 XP\n*En* : ⏱ ${tiempoRestante}`, m, rcanal)
    return
  }

  global.db.data.users[m.sender].exp += isPrems ? prem : free
  conn.reply(m.chat, `Felicidades 🎉, reclamaste *+${isPrems ? prem : free} 💫 XP*.`, m, rcanal)

  cooldowns[m.sender] = Date.now()
}

handler.help = ['weekly']
handler.tags = ['rpg']
handler.command = ['weekly', 'week'] 
handler.register = true

export default handler

function segundosAHMS(segundos) {
  const horas = Math.floor(segundos / 3600)
  const minutos = Math.floor((segundos % 3600) / 60)
  const segundosRestantes = segundos % 60
  return `${horas} horas, ${minutos} minutos y ${segundosRestantes} segundos`;
}