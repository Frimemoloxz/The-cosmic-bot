import fs from 'fs';
import path from 'path';

const handler = async (m, { conn, text, isROwner }) => {
    if (!isROwner) {
        return await conn.sendMessage(m.chat, { text: 'Este comando solo puede ser usado por los owners del bot.' }, { quoted: m });
    }

    if (!text) {
        return await conn.sendMessage(m.chat, { text: 'Uso: .delplug <nombre del plugin>' }, { quoted: m });
    }

    const pluginName = text.trim();
    const pluginPath = path.join('./plugins', `${pluginName}.js`);

    if (fs.existsSync(pluginPath)) {
        fs.unlinkSync(pluginPath);
        return await conn.sendMessage(m.chat, { text: `El plugin "${pluginName}" ha sido eliminado.` }, { quoted: m });
    } else {
        return await conn.sendMessage(m.chat, { text: `No se encontró el plugin "${pluginName}".` }, { quoted: m });
    }
};

handler.help = ['delplug'];
handler.tags = ['owner'];
handler.command = ['delplug'];
handler.rowner = true;

export default handler;