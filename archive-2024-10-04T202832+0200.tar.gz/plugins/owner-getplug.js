import fs from 'fs';
import path from 'path';

const handler = async (m, { conn, args, isROwner, usedPrefix, command }) => {
    if (!isROwner) return; // Solo los dueños pueden usar este comando

    const pluginName = args[0];
    if (!pluginName) {
        return await conn.reply(m.chat, `Uso: ${usedPrefix + command} <nombre del plugin>`, m);
    }

    const pluginPath = path.resolve('./plugins', `${pluginName}.js`);
    if (!fs.existsSync(pluginPath)) {
        return await conn.reply(m.chat, `El plugin "${pluginName}" no existe.`, m);
    }

    try {
        const pluginContent = fs.readFileSync(pluginPath, 'utf8');
        await conn.sendMessage(m.chat, { text: pluginContent }, { quoted: m });
        await conn.sendMessage(m.chat, { document: fs.readFileSync(pluginPath), mimetype: 'application/javascript', fileName: `${pluginName}.js` }, { quoted: m });
    } catch (e) {
        await conn.reply(m.chat, 'Hubo un error al leer el plugin.', m);
    }
};

handler.help = ['getplug <nombre del plugin>'];
handler.tags = ['owner'];
handler.command = ['getplug'];
handler.rowner = true; // Solo los dueños pueden usar este comando

export default handler;