const free = 1000000
const prem = 2000000
const cooldowns = {}

let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender]
  const tiempoEspera = 30 * 24 * 60 * 60 // 30 días en segundos
  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    const tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000))
    conn.reply(m.chat, `Ya has realizado tu pedido mensual.\nRecuerda que solo puedes realizarlo 1 vez cada 30 días.\n\n*Próximo Monto* : +${isPrems ? prem : free} 💫 XP\n*En* : ⏱ ${tiempoRestante}`, m, rcanal)
    return
  }

  global.db.data.users[m.sender].exp += isPrems ? prem : free
  conn.reply(m.chat, `Felicidades 🎉, reclamaste *+${isPrems ? prem : free} 💫 XP*.`, m, rcanal)

  cooldowns[m.sender] = Date.now()
}

handler.help = ['monthly']
handler.tags = ['rpg']
handler.command = ['montly', 'monthly'] 
handler.register = true

export default handler

function segundosAHMS(segundos) {
  const horas = Math.floor(segundos / 3600)
  const minutos = Math.floor((segundos % 3600) / 60)
  const segundosRestantes = segundos % 60
  return `${horas} horas, ${minutos} minutos y ${segundosRestantes} segundos`;
}