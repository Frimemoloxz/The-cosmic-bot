let handler = async (m, { conn, usedPrefix, command }) => {
    if (command === 'hola') {
        conn.reply(m.chat, 'hola cómo estás', m);
    }
};

handler.help = ['hola'];
handler.tags = ['general'];
handler.command = ['hola'];
handler.register = true;
handler.group = false;

export default handler;