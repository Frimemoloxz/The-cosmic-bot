let intervalId = null;

let handler = async (m, { conn, command }) => {
    if (command === 'onautodsowner') {
        if (intervalId !== null) {
            m.reply('Ya hay un intervalo en ejecución.');
            return;
        }

        intervalId = setInterval(() => {
            conn.reply(m.chat, '.dsowner', null);
        }, 20 * 60 * 1000); 

        m.reply('Intervalo de 20 minutos iniciado.');
    } else if (command === 'onautods') {
        if (intervalId !== null) {
            m.reply('Ya hay un intervalo en ejecución.');
            return;
        }

        intervalId = setInterval(() => {
            conn.reply(m.chat, '.ds', null);
        }, 5 * 60 * 1000); 

        m.reply('Intervalo de 5 minutos iniciado.');
    } else if (command === 'stopds') {
        if (intervalId === null) {
            m.reply('No hay ningún intervalo en ejecución.');
            return;
        }

        clearInterval(intervalId);
        intervalId = null;
        m.reply('Intervalo detenido.');
    }
};

handler.help = ['onautodsowner', 'onautods', 'stopds'];
handler.tags = ['automation'];
handler.command = ['onautodsowner', 'onautods', 'stopds']; 
handler.register = true;

export default handler;