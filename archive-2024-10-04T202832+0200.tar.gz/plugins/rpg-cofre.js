const cooldowns = {}

let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  const tiempoEspera = 24 * 60 * 60 

  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    const tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000))
    conn.reply(m.chat, `Ya has abierto un cofre del tesoro hoy.\nRecuerda que solo puedes abrirlo 1 vez cada 24 horas.\n\n*Próximo Cofre* en: ⏱ ${tiempoRestante}`, m)
    return
  }

  // Generar cantidades aleatorias de XP y coinixs
  const xpGanado = Math.floor(Math.random() * (150000 - 50000 + 1)) + 50000
  const coinixsGanados = Math.floor(Math.random() * (250 - 100 + 1)) + 100

  // Actualizar los valores del usuario
  user.exp += xpGanado
  user.limit += coinixsGanados 

  conn.reply(m.chat, `Felicidades 🎉, has abierto un cofre del tesoro y encontrado:\n\n*XP*: +${xpGanado}\n*Coinixs*: +${coinixsGanados}`, m)

  cooldowns[m.sender] = Date.now()
}

handler.help = ['cofre']
handler.tags = ['rpg']
handler.command = ['cofre']
handler.register = true

export default handler

function segundosAHMS(segundos) {
  const horas = Math.floor(segundos / 3600)
  const minutos = Math.floor((segundos % 3600) / 60)
  const segundosRestantes = segundos % 60
  return `${horas} horas, ${minutos} minutos y ${segundosRestantes} segundos`
}