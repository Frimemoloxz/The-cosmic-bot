let cooldowns = {};

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (args.length < 2) return m.reply(`Uso incorrecto. Por favor usa el comando de la siguiente manera:\n\n${usedPrefix + command} (cantidad de coinixs) (cara/cruz)\n\nEjemplo:\n${usedPrefix + command} 10 cara`);
    let cantidad = parseInt(args[0]);
    let eleccion = args[1].toLowerCase();

    if (isNaN(cantidad)) return m.reply('Ingresa una cantidad válida de coinixs para apostar.');
    if (cantidad <= 0) return m.reply('La cantidad de coinixs debe ser mayor que 0.');
    if (eleccion !== 'cara' && eleccion !== 'cruz') return m.reply('La elección debe ser "cara" o "cruz".');

    let users = global.db.data.users[m.sender];
    if (users.limit < cantidad) return m.reply('No tienes suficientes coinixs para hacer esta apuesta.');

    let tiempoEspera = 15;
    if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
        let tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000));
        m.reply(`⏱ Espera *${tiempoRestante}* para apostar nuevamente.`);
        return;
    }

    m.reply('🪙 La moneda ha sido lanzada... Espera 5 segundos para saber el resultado.');

    setTimeout(() => {
        // Lanzar la moneda
        let resultado = Math.random() < 0.5 ? 'cara' : 'cruz';

        if (eleccion === resultado) {
            users.limit += cantidad;
            conn.reply(m.chat, `🎉 ¡Felicidades! La moneda cayó en *${resultado}*. Has ganado *${cantidad}* coinixs.`, m);
        } else {
            users.limit -= cantidad;
            conn.reply(m.chat, `Lo siento. La moneda cayó en *${resultado}*. Has perdido *${cantidad}* coinixs.`, m);
        }

        cooldowns[m.sender] = Date.now();
    }, 5000); // 5 segundos de espera
};

handler.help = ['flip <cantidad> <cara/cruz>'];
handler.tags = ['game'];
handler.command = ['flip'];
handler.register = true;
handler.group = false;

export default handler;

function segundosAHMS(segundos) {
    let segundosRestantes = segundos % 60;
    return `${segundosRestantes} segundos`;
}