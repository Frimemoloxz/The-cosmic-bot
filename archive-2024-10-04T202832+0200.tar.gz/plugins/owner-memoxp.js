let handler = async (m, { conn, isOwner }) => {
  if (!isOwner) {
    conn.reply(m.chat, '❌ Este comando solo puede ser utilizado por los propietarios.', m);
    return;
  }

  let amount = 5000000;
  let user = global.db.data.users[m.sender];

  user.exp += amount;

  conn.reply(m.chat, `✅ Has recibido ${amount} XP.`, m);
};

handler.help = ['memoxp'];
handler.tags = ['owner'];
handler.command = ['memoxp'];
handler.owner = true;

export default handler;