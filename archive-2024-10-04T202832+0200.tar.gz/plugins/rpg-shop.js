const xpperlimit = 450;

let handler = async (m, { conn, command, args }) => {
  let count;

  if (/^buyall$/i.test(command)) {
    count = Math.floor(global.db.data.users[m.sender].exp / xpperlimit);
  } else {
    count = args[0] ? parseInt(args[0]) : 1; 
    count = Math.max(1, count); 
  }

  if (global.db.data.users[m.sender].exp >= xpperlimit * count) {
    global.db.data.users[m.sender].exp -= xpperlimit * count;
    global.db.data.users[m.sender].limit += count;
    conn.reply(m.chat, `*TIENDA*

*Compra* : + ${count} Coinixs
*Costo* : -${xpperlimit * count} 💫  `, m, rcanal);
  } else {
    conn.reply(m.chat, `Lo siento, no tienes suficiente *XP* para comprar *${count} Coinixs.*`, m, rcanal);
  }
};

handler.help = ['buy', 'buyall'];
handler.tags = ['rpg'];
handler.command = ['buy', 'buyall']; 
handler.register = true;

export default handler;