import fetch from 'node-fetch';

let handler = async (m, { conn }) => {
  try {
    // Obtén la foto de perfil del bot
    let pp = await conn.profilePictureUrl(m.sender, 'image');

    // Define respuestas según el texto del mensaje
    let responses = {
      'qué eres': 'Soy una IA diseñada para ayudarte con tus preguntas y tareas.',
      'cómo estás': 'Estoy bien, gracias por preguntar. ¿Y tú?',
      'hola': 'Hola, ¿en qué puedo asistirte hoy?',
      'adiós': 'Hasta luego, ¡cuídate!',
      '': 'Hola, soy Jarvis. ¿Cómo puedo ayudarte?'
    };

    // Encuentra la respuesta adecuada
    let responseText = responses[m.text.toLowerCase()] || responses[''];

    // Crea un mensaje de grupo ficticio para incluir la foto de perfil
    const anu = {
      "key": {
        "fromMe": false,
        "participant": "0@s.whatsapp.net",
        "remoteJid": "0@s.whatsapp.net"
      },
      "message": {
        "groupInviteMessage": {
          "groupJid": "6285240750713-1610340626@g.us",
          "inviteCode": "mememteeeekkeke",
          "groupName": "P",
          "caption": "Hello, I'm Jarvis",
          "jpegThumbnail": await (await fetch(pp)).buffer()
        }
      }
    };

    // Envía el mensaje de respuesta con la foto de perfil del bot
    conn.sendMessage(m.chat, { text: responseText }, { quoted: anu });
  } catch (error) {
    // Responde sin foto de perfil en caso de error
    conn.sendMessage(m.chat, 'Hola, soy Jarvis. ¿Cómo puedo ayudarte?', 'conversation', { quoted: m });
  }
};

// Ajusta el prefijo para que responda a "Jarvis"
handler.customPrefix = /^(Jarvis)$/i;
handler.command = new RegExp;

export default handler;
