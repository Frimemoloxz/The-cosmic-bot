const minXP = 10000
const maxXP = 80000
const cooldowns = {}

let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  const tiempoEspera = 24 * 60 * 60 // 24 horas en segundos
  
  // Verificar si el usuario ya usó el comando hoy
  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    const tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000))
    return conn.reply(m.chat, `Ya has roto tu piñata hoy.\nRecuerda que solo puedes hacerlo 1 vez cada 24 horas.\n\n*Próximo Uso En*: ⏱ ${tiempoRestante}`, m)
  }

  // Generar una cantidad aleatoria de XP
  let xp = Math.floor(Math.random() * (maxXP - minXP + 1)) + minXP
  user.exp += xp

  // Enviar respuesta al usuario
  conn.reply(m.chat, `Has roto tu piñata, has obtenido: *+${xp} 💫 XP*`, m)

  // Actualizar cooldown
  cooldowns[m.sender] = Date.now()
}

handler.help = ['piñata']
handler.tags = ['game']
handler.command = ['piñata']
handler.register = true

// Función para convertir segundos a formato horas, minutos y segundos
function segundosAHMS(segundos) {
  const horas = Math.floor(segundos / 3600)
  const minutos = Math.floor((segundos % 3600) / 60)
  const segundosRestantes = segundos % 60
  return `${horas} horas, ${minutos} minutos y ${segundosRestantes} segundos`
}

export default handler