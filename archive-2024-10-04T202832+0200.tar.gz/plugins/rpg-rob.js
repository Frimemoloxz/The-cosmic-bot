let cooldowns = {};

let handler = async (m, { conn, usedPrefix, command, args }) => {
    let target;
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0];
    } else if (m.quoted) {
        target = m.quoted.sender;
    } else {
        return m.reply(`Uso incorrecto. Por favor usa el comando de la siguiente manera:\n\n${usedPrefix + command} @usuario\nO responde a un mensaje con ${usedPrefix + command}`);
    }

    let user = global.db.data.users[m.sender];
    let targetUser = global.db.data.users[target];
    
    if (!targetUser) return m.reply('El usuario al que intentas robar no está registrado en la base de datos.');
    if (!user) return m.reply('No estás registrado en la base de datos.');

    let tiempoEspera = 4 * 60 * 60 * 1000; // 4 horas en milisegundos
    if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera) {
        let tiempoRestante = msAHorasMinutosSegundos(tiempoEspera - (Date.now() - cooldowns[m.sender]));
        return m.reply(`⏱ Espera *${tiempoRestante}* para poder robar nuevamente.`);
    }

    let coinsRobados = Math.floor(Math.random() * (80 - 10 + 1)) + 10;

    if (targetUser.limit < coinsRobados) {
        coinsRobados = targetUser.limit;  // Si el usuario objetivo tiene menos coins, robamos lo que tenga.
    }

    targetUser.limit -= coinsRobados;
    user.limit += coinsRobados;
    cooldowns[m.sender] = Date.now();

    conn.reply(m.chat, `Has robado *${coinsRobados}* coins a @${target.split('@')[0]}.`, m, {
        mentions: [target]
    });
};

handler.help = ['rob @usuario'];
handler.tags = ['game'];
handler.command = ['rob']; 
handler.register = true;
handler.group = true;

export default handler;

function msAHorasMinutosSegundos(ms) {
    let horas = Math.floor(ms / (1000 * 60 * 60));
    let minutos = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    let segundos = Math.floor((ms % (1000 * 60)) / 1000);
    return `${horas}h ${minutos}m ${segundos}s`;
}