let handler = async (m, { conn, usedPrefix, isOwner }) => {
await m.react('🐦')
await conn.reply(m.chat, `Hola @${m.sender.split`@`[0]} si necesitas la ayuda de memo porfavor escribele al privado\n*- evita der bloqueado, solo cosas importantes.-*`, estilo, { mentions: [m.sender] })
let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:;Fri memo⁩;;\nFN:Fri memo⁩⁩\nORG:Fri memo⁩⁩\nTITLE:\nitem1.TEL;waid=5493804166508:5493804166508\nitem1.X-ABLabel:Fri memo⁩\nX-WA-BIZ-DESCRIPTION:\nX-WA-BIZ-NAME:Fri memo⁩⁩\nEND:VCARD`
await conn.sendMessage(m.chat, { contacts: { displayName: 'Fri memo', contacts: [{ vcard }] }}, {quoted: m})
}
handler.customPrefix = /^(@5493804166508|Memo|frimemo|memo)$/i
handler.command = new RegExp
export default handler