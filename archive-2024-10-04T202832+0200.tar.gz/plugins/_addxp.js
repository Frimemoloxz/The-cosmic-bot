let handler = async (m, { conn, text, isOwner }) => {
  if (!isOwner) {
    conn.reply(m.chat, '❌ Este comando solo puede ser utilizado por los propietarios.', m);
    return;
  }

  let who
  if (m.isGroup) who = m.mentionedJid[0]
  else who = m.chat
  if (!who) throw 'Menciona al usuario con *@user.*'
  let txt = text.replace('@' + who.split`@`[0], '').trim()
  if (!txt) throw 'Ingrese la cantidad de *💫 XP* que quiere otorgar.'
  if (isNaN(txt)) throw 'Sólo números.'
  let xp = parseInt(txt)
  if (xp < 1) throw 'La cantidad mínima de XP es 1.'
  
  let users = global.db.data.users
  if (!users[who]) throw 'El usuario mencionado no existe.'

  users[who].exp += xp

  conn.reply(m.chat, `✅ Has otorgado *${xp} 💫XP* a ${who.split('@')[0]}.`)
}

handler.help = ['addxp *@user <cantidad>*']
handler.tags = ['owner']
handler.command = ['addxp']
handler.owner = true

export default handler
