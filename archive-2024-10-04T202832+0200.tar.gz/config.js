import { watchFile, unwatchFile } from 'fs' 
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'
import cheerio from 'cheerio'
import fetch from 'node-fetch'
import axios from 'axios'
//import moment from 'moment-timezone' 

//*Cosmic bot*

global.owner = [
  ['5493804166508', 'FRI MEMO', true],
  ['5493794796042', 'Rober', true],
  ['50584701161', 'Aluo', true],
  ['5214472208350'],
  ['573012436429'],
  [''],
  [''],
  [''],
  [''],
  ['']

]

//*cosmic bot*

global.mods = []
global.prems = []
   
//*cosmic bot*

global.packname = `+54 9 379 479-6042`
global.author = '{\n "bot": {\n   "name": "Cosmic-Bot",\n     "author": "MDLG-Team⁩",\n   "status_bot": "active"\n }\n}'
global.wait = '🐢 **espere por favor...*'
global.botname = 'Cosmic-Bot-MD'
global.textbot = `Powered By MDLG-Team`
global.listo = '*listo*'
global.namechannel = 'The MDLG-Team OFC channel'

//*cosmic bot*

global.catalogo = fs.readFileSync('./storage/img/catalogo.png')
global.miniurl = fs.readFileSync('./storage/img/miniurl.jpg')

//*cosmic bot*

global.group = 'https://chat.whatsapp.com/G1pE7LsYd1sLivbYhLuoIJ'
global.canal = 'https://whatsapp.com/channel/0029VadwYAfBvvsbqX5VVt3m'

//*cosmic bot*

global.estilo = { key: {  fromMe: false, participant: `0@s.whatsapp.net`, ...(false ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: { orderMessage: { itemCount : -999999, status: 1, surface : 1, message: botname, orderTitle: 'Bang', thumbnail: catalogo, sellerJid: '0@s.whatsapp.net'}}}

//*cosmic bot*

global.cheerio = cheerio
global.fs = fs
global.fetch = fetch
global.axios = axios
//global.moment = moment	

//*cosmic bot*

global.multiplier = 69 
global.maxwarn = '2' // máxima advertencias

//*cosmic bot*

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
